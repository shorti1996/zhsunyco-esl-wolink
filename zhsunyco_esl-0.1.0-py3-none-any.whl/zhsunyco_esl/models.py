from dataclasses import dataclass
from typing import Optional


# Device profiles: all device-specific parameters in one place
DEVICES = {
    "290": {
        "width": 296,
        "height": 128,
        "mirror": True,
        "rotate_cw": True,
        "color": "BWRY",
        "name": "BLE-290BWRY",
    },
    "350": {
        "width": 384,
        "height": 184,
        "mirror": False,
        "rotate_cw": False,
        "color": "BWRY",
        "name": "BLE-350BWRY",
    },
}

# BLE discovery constants
EASYTAG_SERVICE_UUID = "00001523-1212-efde-1523-785feabcd123"
WOLINK_SERVICE_UUID = "30323032-4c53-4545-4c42-4b4e494c4f57"
SERVICE_UUIDS = [EASYTAG_SERVICE_UUID, WOLINK_SERVICE_UUID]
KNOWN_MAC_PREFIX = "66:66:17:"
KNOWN_NAME_PREFIX = "WL"

# Known BLE service profiles for device type detection
KNOWN_PROFILES = [
    # easyTag (older devices)
    {
        "service": EASYTAG_SERVICE_UUID,
        "write": "00001525-1212-efde-1523-785feabcd123",
        "notify": "00001526-1212-efde-1523-785feabcd123",
    },
    # WOLINK (BLE-290BWRY, BLE-350BWRY)
    {
        "service": WOLINK_SERVICE_UUID,
        "write": "31323032-4c53-4545-4c42-4b4e494c4f57",
        "notify": "34323032-4c53-4545-4c42-4b4e494c4f57",
    },
]


@dataclass
class LabelConfig:
    width: int = 296
    height: int = 128
    mirror: bool = False
    rotate_cw: bool = True

    # UUIDs can be set manually, or auto-detected from KNOWN_PROFILES
    write_char_uuid: Optional[str] = None
    notify_char_uuid: Optional[str] = None

    @classmethod
    def from_device(cls, device_key: str) -> "LabelConfig":
        """Create a LabelConfig from a device profile key (e.g., '290', '350')."""
        profile = DEVICES[device_key]
        return cls(
            width=profile["width"],
            height=profile["height"],
            mirror=profile["mirror"],
            rotate_cw=profile["rotate_cw"],
        )


DEFAULT_CONFIG = LabelConfig()
