from math import sqrt
from PIL import Image, ImageEnhance
from typing import Tuple, List, Union
from .models import LabelConfig

# Dithering kernels: list of (dx, dy, weight) tuples
# Index mapping for per-pixel dither mask (0 = none, 1+ = algorithm)
_DITHER_INDEX = {"none": 0, "floyd-steinberg": 1, "atkinson": 2, "stucki": 3}

_DITHER_KERNELS = {
    "floyd-steinberg": [
        (1, 0, 7/16),
        (-1, 1, 3/16),
        (0, 1, 5/16),
        (1, 1, 1/16),
    ],
    "atkinson": [
        (1, 0, 1/8),
        (2, 0, 1/8),
        (-1, 1, 1/8),
        (0, 1, 1/8),
        (1, 1, 1/8),
        (0, 2, 1/8),
    ],
    "stucki": [
        (1, 0, 8/42),
        (2, 0, 4/42),
        (-2, 1, 2/42),
        (-1, 1, 4/42),
        (0, 1, 8/42),
        (1, 1, 4/42),
        (2, 1, 2/42),
        (-2, 2, 1/42),
        (-1, 2, 2/42),
        (0, 2, 4/42),
        (1, 2, 2/42),
        (2, 2, 1/42),
    ],
}

_DITHER_BY_INDEX = [
    None,                              # 0 = none
    _DITHER_KERNELS["floyd-steinberg"],  # 1
    _DITHER_KERNELS["atkinson"],         # 2
    _DITHER_KERNELS["stucki"],           # 3
]

def resize_image(img: Image.Image, width: int, height: int) -> Image.Image:
    """Aggressively resize the image to fit the dimensions."""
    return img.resize((width, height), Image.Resampling.LANCZOS)

def _color_distance(r1, g1, b1, r2, g2, b2):
    """CompuPhase redmean weighted color distance — better perceptual accuracy than Euclidean RGB."""
    r_mean = (r1 + r2) / 2
    dr = r1 - r2
    dg = g1 - g2
    db = b1 - b2
    return sqrt((2 + r_mean / 256) * dr * dr + 4 * dg * dg + (2 + (255 - r_mean) / 256) * db * db)

def _get_palette_color(r, g, b, color_mode):
    """Returns (r, g, b, bw_bit, red_bit, yellow_bit) for the nearest color."""
    dist_black = _color_distance(r, g, b, 0, 0, 0)
    dist_white = _color_distance(r, g, b, 255, 255, 255)
    dist_red = _color_distance(r, g, b, 255, 0, 0)
    dist_yellow = _color_distance(r, g, b, 255, 255, 0)

    if color_mode == "BW":
        if dist_black < dist_white:
            return (0, 0, 0, 1, 0, 0)
        else:
            return (255, 255, 255, 0, 0, 0)

    if color_mode == "BWR":
        min_dist = min(dist_black, dist_white, dist_red)
        if min_dist == dist_black:
            return (0, 0, 0, 1, 0, 0)
        elif min_dist == dist_white:
            return (255, 255, 255, 0, 0, 0)
        else:
            return (255, 0, 0, 0, 1, 0)

    # BWRY Mode
    min_dist = min(dist_black, dist_white, dist_red, dist_yellow)
    if min_dist == dist_black:
        return (0, 0, 0, 1, 0, 0)
    elif min_dist == dist_white:
        return (255, 255, 255, 0, 0, 0)
    elif min_dist == dist_red:
        return (255, 0, 0, 0, 1, 0)
    else:
        return (255, 255, 0, 0, 0, 1)


def quantize_image(img: Image.Image, width: int, height: int,
                 color_mode: str = "BWR",
                 dither: Union[bool, str] = True,
                 saturation: float = 1.0,
                 contrast: float = 1.0,
                 dither_mask: "Image.Image | None" = None) -> Tuple[List[int], List[int], List[int]]:
    """
    Quantize image to palette colors with optional dithering.

    dither: "none", "floyd-steinberg", "atkinson", "stucki",
            or bool for backward compat (True → "floyd-steinberg", False → "none").
    saturation/contrast: enhancement factors applied before quantizing (1.0 = no change).
    dither_mask: optional L-mode image where each pixel value is a dither algorithm
                 index (0=none, 1=floyd-steinberg, 2=atkinson, 3=stucki).
                 When provided, per-pixel algorithm overrides the global dither setting.
    Returns (plane_bw, plane_red, plane_yellow) lists.
    """
    # Normalize bool dither to string
    if isinstance(dither, bool):
        dither = "floyd-steinberg" if dither else "none"

    img = img.convert("RGB")

    # Apply enhancement
    if saturation != 1.0:
        img = ImageEnhance.Color(img).enhance(saturation)
    if contrast != 1.0:
        img = ImageEnhance.Contrast(img).enhance(contrast)

    pixels = img.load()
    global_kernel = _DITHER_KERNELS.get(dither)

    mask_px = None
    if dither_mask is not None:
        mask_px = dither_mask.load()

    for y in range(height):
        for x in range(width):
            old_r, old_g, old_b = pixels[x, y]

            new_r, new_g, new_b, _, _, _ = _get_palette_color(old_r, old_g, old_b, color_mode)
            pixels[x, y] = (new_r, new_g, new_b)

            # Resolve kernel: per-pixel from mask, or global
            if mask_px is not None:
                idx = mask_px[x, y]
                kernel = _DITHER_BY_INDEX[idx] if idx < len(_DITHER_BY_INDEX) else None
            else:
                kernel = global_kernel

            if kernel:
                err_r = old_r - new_r
                err_g = old_g - new_g
                err_b = old_b - new_b

                for dx, dy, factor in kernel:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < width and 0 <= ny < height:
                        if mask_px is not None and mask_px[nx, ny] == 0:
                            continue
                        nr, ng, nb = pixels[nx, ny]
                        pixels[nx, ny] = (
                            int(max(0, min(255, nr + err_r * factor))),
                            int(max(0, min(255, ng + err_g * factor))),
                            int(max(0, min(255, nb + err_b * factor)))
                        )

    # Extract bit planes
    plane_bw = []
    plane_red = []
    plane_yellow = []

    for y in range(height):
        for x in range(width):
            r, g, b = pixels[x, y]
            _, _, _, bw_bit, red_bit, yellow_bit = _get_palette_color(r, g, b, color_mode)
            plane_bw.append(bw_bit)
            plane_red.append(red_bit)
            plane_yellow.append(yellow_bit)

    return plane_bw, plane_red, plane_yellow


def render_preview(plane_bw: List[int], plane_red: List[int],
                   plane_yellow: List[int],
                   width: int, height: int) -> Image.Image:
    """Reconstruct an RGB PIL Image from quantized bit planes.

    Maps: bw=1 -> black, red=1 -> red, yellow=1 -> yellow, else white.
    """
    preview = Image.new("RGB", (width, height), "white")
    pixels = preview.load()
    for y in range(height):
        for x in range(width):
            idx = y * width + x
            if plane_bw[idx]:
                pixels[x, y] = (0, 0, 0)
            elif plane_red[idx]:
                pixels[x, y] = (255, 0, 0)
            elif plane_yellow[idx]:
                pixels[x, y] = (255, 255, 0)
    return preview


def _apply_channel_toggles(plane_bw, plane_red, plane_yellow, enable_red, enable_yellow):
    """Zero out disabled color channel planes."""
    if not enable_red:
        plane_red = [0] * len(plane_red)
    if not enable_yellow:
        plane_yellow = [0] * len(plane_yellow)
    return plane_bw, plane_red, plane_yellow


def process_image(image_path: str, config: LabelConfig,
                  color_mode: str = "BWR",
                  dither: Union[bool, str] = True,
                  saturation: float = 1.0,
                  contrast: float = 1.0,
                  enable_red: bool = True,
                  enable_yellow: bool = True) -> Tuple[List[int], List[int], List[int]]:
    """Load, resize, and process an image from path."""
    img = Image.open(image_path)
    img = resize_image(img, config.width, config.height)
    planes = quantize_image(img, config.width, config.height, color_mode,
                            dither=dither, saturation=saturation, contrast=contrast)
    return _apply_channel_toggles(*planes, enable_red, enable_yellow)


def process_pil_image(img: Image.Image, config: LabelConfig,
                      color_mode: str = "BWR",
                      dither: Union[bool, str] = True,
                      saturation: float = 1.0,
                      contrast: float = 1.0,
                      enable_red: bool = True,
                      enable_yellow: bool = True,
                      dither_mask: "Image.Image | None" = None) -> Tuple[List[int], List[int], List[int]]:
    """Resize and process an in-memory PIL Image."""
    img = resize_image(img, config.width, config.height)
    if dither_mask is not None:
        dither_mask = dither_mask.resize((config.width, config.height), Image.Resampling.NEAREST)
    planes = quantize_image(img, config.width, config.height, color_mode,
                            dither=dither, saturation=saturation, contrast=contrast,
                            dither_mask=dither_mask)
    return _apply_channel_toggles(*planes, enable_red, enable_yellow)
