"""WOLINK block compression format encoder."""

import zlib

WOLINK_BLOCK_SIZE = 8192


def compress_wolink_blocks(data: bytes) -> bytes:
    """Compress a raw 2bpp buffer using the WOLINK block deflate format.

    Format: A5 A6 <N> 02 [<idx> <size_u16le> <raw_deflate>] x N
    Byte 2 = block count, byte 3 = format type (always 0x02).
    Block indices are 1-based sequential (01, 02, 03, ..., N).
    Each block holds up to 8192 bytes of uncompressed data.
    """
    blocks = []
    for offset in range(0, len(data), WOLINK_BLOCK_SIZE):
        blocks.append(data[offset:offset + WOLINK_BLOCK_SIZE])

    result = bytearray([0xA5, 0xA6, len(blocks), 0x02])

    for i, block in enumerate(blocks):
        obj = zlib.compressobj(9, zlib.DEFLATED, -15)
        compressed = obj.compress(block) + obj.flush()
        result.append(i + 1)  # 1-based block index
        result.extend(len(compressed).to_bytes(2, "little"))
        result.extend(compressed)

    return bytes(result)
