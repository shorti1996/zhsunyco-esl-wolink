import asyncio
import io
import click
from PIL import Image, ImageDraw
import barcode
from barcode.writer import ImageWriter
from zhsunyco_esl import ZhsunycoClient
from zhsunyco_esl.image import quantize_image
from zhsunyco_esl.cli._common import device_options, get_config, get_device_profile, load_font


@click.command()
@click.version_option()
@click.option('--mac', required=True, help='MAC address of the label')
@device_options
def main(mac, device):
    """Sends a factory-style demo pattern showing all 4 colors, model name, ID, and barcode."""

    profile = get_device_profile(device)
    config = get_config(device)
    width, height = config.width, config.height
    model = profile['name']

    # Derive device ID from MAC (strip 6666 prefix)
    device_id = mac.replace(":", "").lower()
    if device_id.startswith("6666"):
        device_id = device_id[4:]

    print(f"Generating demo pattern for {model} ({width}x{height})...")

    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)

    # Fonts
    font_model = load_font(14)
    font_id = load_font(11)

    # --- Color swatches (centered, upper area) ---
    swatch_w = 45
    swatch_h = 28
    gap = 6
    total_swatch_w = swatch_w * 4 + gap * 3
    swatch_x0 = (width - total_swatch_w) // 2
    swatch_y0 = 18

    colors = [
        ("white", "black"),
        ("red", None),
        ((255, 200, 0), None),
        ("black", None),
    ]

    for i, (fill, border_color) in enumerate(colors):
        x = swatch_x0 + i * (swatch_w + gap)
        y = swatch_y0
        draw.rectangle([x, y, x + swatch_w, y + swatch_h], fill=fill, outline="black", width=1)

    # --- Model name centered below swatches ---
    model_bbox = draw.textbbox((0, 0), model, font=font_model)
    model_w = model_bbox[2] - model_bbox[0]
    model_x = (width - model_w) // 2
    model_y = swatch_y0 + swatch_h + 10
    draw.text((model_x, model_y), model, fill="black", font=font_model)

    # --- Device ID bottom-left ---
    id_y = height - 42
    draw.text((8, id_y), device_id, fill="black", font=font_id)

    # --- Barcode bottom-left ---
    try:
        code128 = barcode.get_barcode_class('code128')
        writer = ImageWriter()
        generated = code128(device_id, writer=writer)
        buf = io.BytesIO()
        generated.write(buf, options={
            'write_text': False,
            'module_height': 6.0,
            'module_width': 0.3,
            'quiet_zone': 0.5,
        })
        buf.seek(0)
        barcode_img = Image.open(buf)

        bc_target_w = min(140, width // 2)
        bc_aspect = barcode_img.width / barcode_img.height
        bc_target_h = int(bc_target_w / bc_aspect)
        if bc_target_h > 20:
            bc_target_h = 20
            bc_target_w = int(bc_target_h * bc_aspect)
        barcode_resized = barcode_img.resize((bc_target_w, bc_target_h), Image.Resampling.NEAREST)
        canvas.paste(barcode_resized, (8, height - 22))
    except Exception:
        pass

    # --- Bluetooth icon bottom-right ---
    bt_x = width - 30
    bt_y = height - 35
    draw.line([(bt_x + 8, bt_y), (bt_x + 8, bt_y + 24)], fill="black", width=2)
    draw.line([(bt_x + 8, bt_y), (bt_x + 18, bt_y + 8)], fill="black", width=2)
    draw.line([(bt_x + 18, bt_y + 8), (bt_x + 2, bt_y + 18)], fill="black", width=2)
    draw.line([(bt_x + 2, bt_y + 6), (bt_x + 18, bt_y + 16)], fill="black", width=2)
    draw.line([(bt_x + 18, bt_y + 16), (bt_x + 8, bt_y + 24)], fill="black", width=2)

    # --- Process and send ---
    plane_bw, plane_red, plane_yellow = quantize_image(canvas, width, height, color_mode="BWRY", dither=False)

    client = ZhsunycoClient(mac, config=config)

    try:
        asyncio.run(client.send_image_planes(plane_bw, plane_red, plane_yellow))
    except Exception as e:
        print(f"Error: {e}")
        ctx = click.get_current_context()
        ctx.exit(1)


if __name__ == "__main__":
    main()
