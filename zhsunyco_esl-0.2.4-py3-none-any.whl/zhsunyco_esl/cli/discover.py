import asyncio
import click
from bleak import BleakClient, BleakScanner


async def _discover(mac, timeout):
    print(f"Scanning for {mac}...")
    device = await BleakScanner.find_device_by_address(mac, timeout=timeout)
    if not device:
        print(f"Device {mac} not found")
        return

    print(f"Connecting to {device.address}...")
    async with BleakClient(device, timeout=30.0) as client:
        print(f"Connected.\n")
        for service in client.services:
            print(f"Service: {service.uuid}")
            for char in service.characteristics:
                props = ", ".join(char.properties)
                print(f"  Characteristic: {char.uuid}  [{props}]")
                for desc in char.descriptors:
                    print(f"    Descriptor: {desc.uuid}")


@click.command()
@click.option("--mac", required=True, help="MAC address of the device")
@click.option("--timeout", default=30.0, help="Scan timeout in seconds")
def main(mac, timeout):
    """Discover GATT services and characteristics of a BLE device."""
    asyncio.run(_discover(mac, timeout))


if __name__ == "__main__":
    main()
