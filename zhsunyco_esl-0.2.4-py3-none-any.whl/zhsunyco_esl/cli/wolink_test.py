"""Quick test script to probe WOLINK protocol data format."""
import asyncio
import click
from bleak import BleakClient, BleakScanner
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

AES_KEY = bytes([
    0x9B, 0x60, 0x9F, 0x28, 0xBC, 0x49, 0xE2, 0x57,
    0x29, 0xBD, 0x7B, 0x8D, 0xF2, 0x2B, 0x44, 0x20,
])
AUTH_CHAR = "33323032-4c53-4545-4c42-4b4e494c4f57"
DATA_CHAR = "31323032-4c53-4545-4c42-4b4e494c4f57"
NOTIFY_CHARS = [
    ("34", "34323032-4c53-4545-4c42-4b4e494c4f57"),
    ("35", "35323032-4c53-4545-4c42-4b4e494c4f57"),
]


async def authenticate(client):
    nonce = await client.read_gatt_char(AUTH_CHAR)
    print(f"  Nonce: {nonce.hex()}")
    cipher = Cipher(algorithms.AES(AES_KEY), modes.ECB())
    enc = cipher.encryptor()
    encrypted = enc.update(bytes(nonce)) + enc.finalize()
    await client.write_gatt_char(AUTH_CHAR, encrypted, response=True)
    print("  Authenticated.")
    await asyncio.sleep(0.5)


async def subscribe_all(client):
    def make_handler(cid):
        def h(s, d):
            print(f"  << Notify[{cid}]: {d.hex()} ({len(d)} bytes)")
        return h

    for cid, uuid in NOTIFY_CHARS:
        try:
            await client.start_notify(uuid, make_handler(cid))
        except Exception as e:
            print(f"  Could not subscribe {cid}: {e}")
    await asyncio.sleep(0.3)


async def send_chunks(client, raw, chunk_size=128, big_endian=False, response=True):
    total = len(raw)
    offset = 0
    while offset < total:
        chunk = raw[offset:offset + chunk_size]
        cmd = bytearray([0xA5, 0x00])
        order = 'big' if big_endian else 'little'
        cmd.extend(offset.to_bytes(4, order))
        cmd.extend(chunk)
        await client.write_gatt_char(DATA_CHAR, bytes(cmd), response=response)
        offset += len(chunk)
        await asyncio.sleep(0.02)
    print(f"  Sent {total} bytes in {(total + chunk_size - 1) // chunk_size} chunks (chunk_size={chunk_size}, response={response})")


async def send_refresh(client, size, cmd_byte=0x01, big_endian=False):
    cmd = bytearray([0xA5, cmd_byte])
    order = 'big' if big_endian else 'little'
    cmd.extend(size.to_bytes(4, order))
    print(f"  Refresh cmd: 0xA5{cmd_byte:02X} size={size} ({'BE' if big_endian else 'LE'}: {cmd.hex()})")
    await client.write_gatt_char(DATA_CHAR, bytes(cmd), response=True)
    await asyncio.sleep(5)


async def _test(mac, width, height, test_num):
    print(f"Scanning for {mac}...")
    device = await BleakScanner.find_device_by_address(mac, timeout=120.0)
    if not device:
        print("Not found")
        return

    async with BleakClient(device, timeout=60.0) as client:
        print("Connected.")
        await asyncio.sleep(1.0)

        # Check MTU
        mtu = client.mtu_size
        print(f"  MTU: {mtu}")

        await authenticate(client)
        await subscribe_all(client)

        # Try reading data characteristic for status
        try:
            status = await client.read_gatt_char(DATA_CHAR)
            print(f"  Data char read: {status.hex()} ({len(status)} bytes)")
        except Exception as e:
            print(f"  Data char read failed: {e}")

        total_pixels = width * height
        bw_plane_size = total_pixels // 8  # 1bpp

        if test_num == 7:
            # Test 7: 3 planes for BWRY (BW + Red + Yellow)
            print("\n=== Test 7: 3 planes (BW+Red+Yellow), 14208 bytes ===")
            raw = bytearray([0xFF] * bw_plane_size)  # BW: all black
            raw += bytearray([0x00] * bw_plane_size)  # Red: none
            raw += bytearray([0x00] * bw_plane_size)  # Yellow: none
            await send_chunks(client, raw)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 8:
            # Test 8: Small chunks (16 bytes) to avoid MTU issues
            print(f"\n=== Test 8: 1bpp BW, small chunks (16 bytes), MTU={mtu} ===")
            raw = bytearray([0xFF] * bw_plane_size)
            await send_chunks(client, raw, chunk_size=16)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 9:
            # Test 9: 2bpp with different color mapping (00=black, 11=white)
            print("\n=== Test 9: 2bpp inverted (00=black=all 0x00), refresh byte count ===")
            raw = bytearray([0x00] * (total_pixels // 4))  # all 00 = all black
            await send_chunks(client, raw)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 10:
            # Test 10: Try reading ALL characteristics for any info
            print("\n=== Test 10: Read all characteristics ===")
            for service in client.services:
                for char in service.characteristics:
                    if "read" in char.properties:
                        try:
                            val = await client.read_gatt_char(char.uuid)
                            print(f"  {char.uuid[:8]}: {val.hex()} ({len(val)} bytes) = {val}")
                        except Exception as e:
                            print(f"  {char.uuid[:8]}: read failed: {e}")

        elif test_num == 11:
            # Test 11: Send just the refresh command WITHOUT any data first
            print("\n=== Test 11: Refresh only (0xA501), no data ===")
            await send_refresh(client, bw_plane_size, 0x01)

        elif test_num == 12:
            # Test 12: 1bpp half-black half-white pattern (visible test)
            print("\n=== Test 12: 1bpp BW half-half pattern ===")
            raw = bytearray()
            half = bw_plane_size // 2
            raw += bytearray([0xFF] * half)  # top half: black
            raw += bytearray([0x00] * half)  # bottom half: white
            await send_chunks(client, raw)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 13:
            # Test 13: Try writing raw data to data char WITHOUT command prefix
            print("\n=== Test 13: Raw data without 0xA500 prefix ===")
            raw = bytearray([0xFF] * bw_plane_size)
            chunk_size = 128
            offset = 0
            while offset < len(raw):
                chunk = raw[offset:offset + chunk_size]
                await client.write_gatt_char(DATA_CHAR, bytes(chunk), response=True)
                offset += len(chunk)
            print(f"  Sent {len(raw)} bytes raw")
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 14:
            # Test 14: Try 0xA5 0x00 with 2-byte offset instead of 4-byte
            print("\n=== Test 14: 2-byte offset (instead of 4-byte) ===")
            raw = bytearray([0xFF] * bw_plane_size)
            chunk_size = 128
            offset = 0
            while offset < len(raw):
                chunk = raw[offset:offset + chunk_size]
                cmd = bytearray([0xA5, 0x00])
                cmd.extend(offset.to_bytes(2, 'little'))
                cmd.extend(chunk)
                await client.write_gatt_char(DATA_CHAR, bytes(cmd), response=True)
                offset += len(chunk)
            print(f"  Sent {len(raw)} bytes with 2-byte offsets")
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 15:
            # Test 15: MTU-safe chunks, response=False to avoid overwhelming device
            print(f"\n=== Test 15: MTU-safe (14-byte chunks), response=False ===")
            raw = bytearray([0xFF] * bw_plane_size)  # all black
            await send_chunks(client, raw, chunk_size=14, response=False)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 16:
            # Test 16: MTU-safe, 2 planes (BW+Red), BWR format
            print(f"\n=== Test 16: MTU-safe, 2 planes BW+Red (9472 bytes) ===")
            raw = bytearray([0xFF] * bw_plane_size)  # BW: all black
            raw += bytearray([0x00] * bw_plane_size)  # Red: none
            await send_chunks(client, raw, chunk_size=14)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 17:
            # Test 17: MTU-safe, negotiate MTU first, then use larger chunks
            print(f"\n=== Test 17: Request MTU 512, then send with appropriate chunks ===")
            # Try to request larger MTU
            try:
                new_mtu = await client.request_mtu(512)
                print(f"  Negotiated MTU: {new_mtu}")
            except Exception as e:
                print(f"  MTU negotiation failed: {e}, using default")
            actual_mtu = client.mtu_size
            max_write = actual_mtu - 3  # ATT overhead
            chunk_size = max(max_write - 6, 14)  # 6 bytes for cmd+offset
            print(f"  Actual MTU: {actual_mtu}, max write: {max_write}, chunk_size: {chunk_size}")
            raw = bytearray([0xFF] * bw_plane_size)
            await send_chunks(client, raw, chunk_size=chunk_size)
            await send_refresh(client, len(raw), 0x01)

        elif test_num == 18:
            # Test 18: Check data pointer after writing
            print(f"\n=== Test 18: Write small data, check pointer ===")
            # Write 14 bytes at offset 0
            cmd = bytearray([0xA5, 0x00, 0x00, 0x00, 0x00, 0x00])
            cmd.extend(bytearray([0xFF] * 14))
            await client.write_gatt_char(DATA_CHAR, bytes(cmd), response=True)
            print(f"  Wrote 14 bytes at offset 0")
            # Read data char to see if pointer updated
            try:
                status = await client.read_gatt_char(DATA_CHAR)
                print(f"  Data char after write: {status.hex()}")
            except Exception as e:
                print(f"  Read failed: {e}")

        else:
            print(f"Unknown test number: {test_num}")
            return

        print("\nWaiting 10s for any notify responses...")
        await asyncio.sleep(10)
        print("Done.")


@click.command()
@click.option("--mac", required=True)
@click.option("--width", default=296)
@click.option("--height", default=128)
@click.option("--test", "test_num", default=7, type=int, help="Test number 7-14")
def main(mac, width, height, test_num):
    """Test different WOLINK data formats."""
    asyncio.run(_test(mac, width, height, test_num))


if __name__ == "__main__":
    main()
