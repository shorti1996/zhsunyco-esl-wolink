import asyncio
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import click

from zhsunyco_esl import ZhsunycoClient
from zhsunyco_esl.image import resize_image, quantize_image, render_preview
from zhsunyco_esl.cli._common import device_options, get_config, get_device_profile


class CropSendApp:
    def __init__(self, root, image_path, mac, config, color_mode):
        self.root = root
        self.mac = mac
        self.config = config
        self.display_w = config.width
        self.display_h = config.height
        self.color_mode = color_mode
        self.aspect = self.display_w / self.display_h

        self.root.title("Crop & Send to E-Ink Label")

        # Load source image
        self.source_img = Image.open(image_path).convert("RGB")
        src_w, src_h = self.source_img.size

        # Scale source to fit in canvas (max 800x600)
        max_canvas_w, max_canvas_h = 800, 600
        self.scale = min(max_canvas_w / src_w, max_canvas_h / src_h, 1.0)
        self.canvas_w = int(src_w * self.scale)
        self.canvas_h = int(src_h * self.scale)

        self.display_img = self.source_img.resize(
            (self.canvas_w, self.canvas_h), Image.Resampling.LANCZOS
        )
        self.tk_source = ImageTk.PhotoImage(self.display_img)

        # Canvas for source image + crop rectangle
        self.canvas = tk.Canvas(root, width=self.canvas_w, height=self.canvas_h, cursor="crosshair")
        self.canvas.pack(padx=10, pady=(10, 5))
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_source)

        # --- Controls frame ---
        controls_frame = tk.Frame(root)
        controls_frame.pack(padx=10, pady=5, fill=tk.X)

        # Dither algorithm dropdown
        tk.Label(controls_frame, text="Dither:").pack(side=tk.LEFT)
        self.dither_var = tk.StringVar(value="Atkinson")
        dither_menu = tk.OptionMenu(
            controls_frame, self.dither_var,
            "None", "Floyd-Steinberg", "Atkinson", "Stucki",
            command=lambda _: self._update_preview()
        )
        dither_menu.pack(side=tk.LEFT, padx=(0, 10))

        # Color channel checkboxes
        self.red_var = tk.BooleanVar(value=True)
        self.yellow_var = tk.BooleanVar(value=True)
        tk.Checkbutton(controls_frame, text="Red", variable=self.red_var,
                       command=self._update_preview).pack(side=tk.LEFT, padx=(0, 5))
        tk.Checkbutton(controls_frame, text="Yellow", variable=self.yellow_var,
                       command=self._update_preview).pack(side=tk.LEFT, padx=(0, 10))

        # Saturation slider
        tk.Label(controls_frame, text="Sat:").pack(side=tk.LEFT)
        self.saturation_var = tk.DoubleVar(value=1.5)
        sat_slider = tk.Scale(controls_frame, from_=0.5, to=3.0, resolution=0.1,
                              orient=tk.HORIZONTAL, variable=self.saturation_var,
                              length=100, showvalue=True,
                              command=lambda _: self._update_preview())
        sat_slider.pack(side=tk.LEFT, padx=(0, 10))

        # Contrast slider
        tk.Label(controls_frame, text="Con:").pack(side=tk.LEFT)
        self.contrast_var = tk.DoubleVar(value=1.2)
        con_slider = tk.Scale(controls_frame, from_=0.5, to=3.0, resolution=0.1,
                              orient=tk.HORIZONTAL, variable=self.contrast_var,
                              length=100, showvalue=True,
                              command=lambda _: self._update_preview())
        con_slider.pack(side=tk.LEFT)

        # Preview label + canvas
        preview_frame = tk.Frame(root)
        preview_frame.pack(padx=10, pady=5)
        tk.Label(preview_frame, text="Preview (as seen on display):").pack(anchor=tk.W)

        # Preview at 2x display size for visibility
        self.preview_scale = 2
        preview_w = self.display_w * self.preview_scale
        preview_h = self.display_h * self.preview_scale
        self.preview_canvas = tk.Canvas(preview_frame, width=preview_w, height=preview_h, bg="#cccccc")
        self.preview_canvas.pack()
        self.tk_preview = None

        # Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(padx=10, pady=10, fill=tk.X)
        self.send_btn = tk.Button(btn_frame, text="Send", command=self._on_send, state=tk.DISABLED, width=12)
        self.send_btn.pack(side=tk.LEFT)
        tk.Button(btn_frame, text="Cancel", command=root.destroy, width=12).pack(side=tk.RIGHT)

        # Crop state
        self.rect_id = None
        self.start_x = 0
        self.start_y = 0
        self.crop_box = None  # (x1, y1, x2, y2) in source image coordinates
        self.plane_bw = None
        self.plane_red = None

        # Move state
        self._moving = False
        self._move_offset_x = 0
        self._move_offset_y = 0

        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)

    def _click_inside_rect(self, x, y):
        """Check if (x, y) is inside the current selection rectangle."""
        if not self.rect_id:
            return False
        x1, y1, x2, y2 = self.canvas.coords(self.rect_id)
        return x1 <= x <= x2 and y1 <= y <= y2

    def _on_press(self, event):
        if self._click_inside_rect(event.x, event.y):
            # Enter move mode
            self._moving = True
            x1, y1, _, _ = self.canvas.coords(self.rect_id)
            self._move_offset_x = event.x - x1
            self._move_offset_y = event.y - y1
        else:
            # New selection
            self._moving = False
            self.start_x = event.x
            self.start_y = event.y
            if self.rect_id:
                self.canvas.delete(self.rect_id)
                self.rect_id = None

    def _on_drag(self, event):
        if self._moving:
            # Move existing rectangle
            x1, y1, x2, y2 = self.canvas.coords(self.rect_id)
            w = x2 - x1
            h = y2 - y1

            new_x1 = event.x - self._move_offset_x
            new_y1 = event.y - self._move_offset_y

            # Clamp to canvas
            new_x1 = max(0, min(self.canvas_w - w, new_x1))
            new_y1 = max(0, min(self.canvas_h - h, new_y1))

            self.canvas.coords(self.rect_id, new_x1, new_y1, new_x1 + w, new_y1 + h)
        else:
            # Draw new selection
            if self.rect_id:
                self.canvas.delete(self.rect_id)

            # Calculate rectangle with locked aspect ratio
            dx = event.x - self.start_x
            dy = event.y - self.start_y

            # Use the larger drag axis to determine size
            if abs(dx) / self.aspect > abs(dy):
                w = abs(dx)
                h = w / self.aspect
            else:
                h = abs(dy)
                w = h * self.aspect

            # Determine direction
            x1 = self.start_x - w if dx < 0 else self.start_x
            y1 = self.start_y - h if dy < 0 else self.start_y
            x2 = x1 + w
            y2 = y1 + h

            # Clamp to canvas, then fix aspect ratio
            if x1 < 0:
                x1 = 0
                w = x2 - x1
                h = w / self.aspect
                if dy < 0:
                    y1 = self.start_y - h
                else:
                    y2 = y1 + h
            if y1 < 0:
                y1 = 0
                h = y2 - y1
                w = h * self.aspect
                if dx < 0:
                    x1 = self.start_x - w
                else:
                    x2 = x1 + w
            if x2 > self.canvas_w:
                x2 = self.canvas_w
                w = x2 - x1
                h = w / self.aspect
                if dy < 0:
                    y1 = self.start_y - h
                else:
                    y2 = y1 + h
            if y2 > self.canvas_h:
                y2 = self.canvas_h
                h = y2 - y1
                w = h * self.aspect
                if dx < 0:
                    x1 = self.start_x - w
                else:
                    x2 = x1 + w

            self.rect_id = self.canvas.create_rectangle(
                x1, y1, x2, y2, outline="red", width=2, dash=(4, 4)
            )

    def _on_release(self, event):
        if not self.rect_id:
            return

        coords = self.canvas.coords(self.rect_id)
        if len(coords) != 4:
            return

        x1, y1, x2, y2 = coords

        # Minimum selection size
        if abs(x2 - x1) < 10 or abs(y2 - y1) < 10:
            return

        # Convert canvas coords to source image coords
        sx1 = int(x1 / self.scale)
        sy1 = int(y1 / self.scale)
        sx2 = int(x2 / self.scale)
        sy2 = int(y2 / self.scale)

        # Clamp to source image
        src_w, src_h = self.source_img.size
        sx1 = max(0, min(sx1, src_w))
        sy1 = max(0, min(sy1, src_h))
        sx2 = max(0, min(sx2, src_w))
        sy2 = max(0, min(sy2, src_h))

        self.crop_box = (sx1, sy1, sx2, sy2)
        self._update_preview()

    def _get_dither_mode(self):
        """Map dropdown value to dither parameter string."""
        mapping = {
            "None": "none",
            "Floyd-Steinberg": "floyd-steinberg",
            "Atkinson": "atkinson",
            "Stucki": "stucki",
        }
        return mapping[self.dither_var.get()]

    def _update_preview(self):
        if not self.crop_box:
            return

        # Crop and resize to display dimensions
        cropped = self.source_img.crop(self.crop_box)
        resized = resize_image(cropped, self.display_w, self.display_h)

        # Dither for preview
        self.plane_bw, self.plane_red, self.plane_yellow = quantize_image(
            resized.copy(), self.display_w, self.display_h, self.color_mode,
            dither=self._get_dither_mode(),
            saturation=self.saturation_var.get(),
            contrast=self.contrast_var.get(),
        )

        # Zero out unchecked color channels
        if not self.red_var.get():
            self.plane_red = [0] * len(self.plane_red)
        if not self.yellow_var.get():
            self.plane_yellow = [0] * len(self.plane_yellow)

        # Reconstruct preview image from planes
        preview = render_preview(self.plane_bw, self.plane_red, self.plane_yellow,
                                 self.display_w, self.display_h)

        # Scale up for visibility
        preview_w = self.display_w * self.preview_scale
        preview_h = self.display_h * self.preview_scale
        preview = preview.resize((preview_w, preview_h), Image.Resampling.NEAREST)

        self.tk_preview = ImageTk.PhotoImage(preview)
        self.preview_canvas.delete("all")
        self.preview_canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_preview)

        self.send_btn.config(state=tk.NORMAL)

    def _on_send(self):
        if self.plane_bw is None:
            return

        self.send_btn.config(state=tk.DISABLED, text="Sending...")
        self.root.update()

        client = ZhsunycoClient(self.mac, config=self.config)

        try:
            asyncio.run(client.send_image_planes(self.plane_bw, self.plane_red, self.plane_yellow))
            messagebox.showinfo("Success", "Image sent to display!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send: {e}")
        finally:
            self.send_btn.config(state=tk.NORMAL, text="Send")


@click.command()
@click.option("--mac", required=True, help="MAC address of the label")
@click.option("--image", "image_path", required=True, type=click.Path(exists=True), help="Path to image file")
@device_options
def main(mac, image_path, device):
    """Open an image, crop interactively, and send to the e-ink label."""
    profile = get_device_profile(device)
    config = get_config(device)
    root = tk.Tk()
    CropSendApp(root, image_path, mac, config, profile['color'])
    root.mainloop()


if __name__ == "__main__":
    main()
