from dataclasses import dataclass


# Device profiles: all device-specific parameters in one place
DEVICES = {
    "290": {
        "width": 296,
        "height": 128,
        "mirror": True,
        "rotate_cw": True,
        "color": "BWRY",
        "name": "BLE-290BWRY",
    },
    "350": {
        "width": 384,
        "height": 184,
        "mirror": False,
        "rotate_cw": False,
        "color": "BWRY",
        "name": "BLE-350BWRY",
    },
    "750": {
        "width": 800,
        "height": 480,
        "mirror": False,
        "rotate_cw": False,
        "row_major": True,
        "color": "BWRY",
        "name": "BLE-750BWRY",
    },
}

# BLE discovery constants
WOLINK_SERVICE_UUID = "30323032-4c53-4545-4c42-4b4e494c4f57"
SERVICE_UUIDS = [WOLINK_SERVICE_UUID]
KNOWN_MAC_PREFIX = "66:66:17:"
KNOWN_NAME_PREFIX = "WL"

# Known BLE service profiles
KNOWN_PROFILES = [
    {
        "service": WOLINK_SERVICE_UUID,
        "write": "31323032-4c53-4545-4c42-4b4e494c4f57",
        "notify": "34323032-4c53-4545-4c42-4b4e494c4f57",
    },
]


@dataclass
class LabelConfig:
    width: int = 296
    height: int = 128
    mirror: bool = False
    rotate_cw: bool = True
    row_major: bool = False

    @classmethod
    def from_device(cls, device_key: str) -> "LabelConfig":
        """Create a LabelConfig from a device profile key (e.g., '290', '350')."""
        profile = DEVICES[device_key]
        return cls(
            width=profile["width"],
            height=profile["height"],
            mirror=profile["mirror"],
            rotate_cw=profile["rotate_cw"],
            row_major=profile.get("row_major", False),
        )


DEFAULT_CONFIG = LabelConfig()
